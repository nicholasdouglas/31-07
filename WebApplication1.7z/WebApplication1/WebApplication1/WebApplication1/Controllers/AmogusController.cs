﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class AmogusController : Controller
    {
        public IActionResult Index()
        {
            var amogus = new List<Amogus>
            {
                new Amogus
                {
                    Id = 1,
                    Nome = "Devolva",
                    Valor = 2.4m,
                    Descr = "Graças ao diabo mãe",
                    DataFabric = new DateTime (2024, 07, 31, 09, 42, 04)

                },
                new Amogus
                {
                    Id = 2,
                    Nome = "Receba",
                    Valor = 0.1m,
                    Descr = "Graças A Deus Pai",
                    DataFabric = new DateTime(2024, 07, 31, 09, 42, 04)
                }
            };

            return View(amogus);
        }
    }
}

