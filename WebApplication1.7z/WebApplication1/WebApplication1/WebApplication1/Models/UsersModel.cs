﻿namespace WebApplication1.Models
{
    public class Users
    {
        public int IdUser { get; set; }
        public string NomeUser { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public int IdadeAno { get; set; }


    }
}
