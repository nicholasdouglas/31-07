﻿namespace WebApplication1.Models
{
    public class Amogus
    {

        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public decimal Valor { get; set; }
        public string Descr { get; set; } = string.Empty;
        public DateTime DataFabric { get; set; } 
    }
}
